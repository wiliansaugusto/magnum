<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Editar Palestrante</h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                    <form method="POST" action="/dashboard/palestrante/update/<?php echo e($data->id); ?>" id="palestrante"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="x_content">
                            <div class="col-md-2 col-sm-2  profile_left">
                                <div class="col-md-12 col-sm-12">
                                    <div id="crop-avatar">
                                        <img id="imgFoto" class="img-responsive avatar-view"
                                             src="<?php echo e($data->ds_foto != "" ? storage_path('public/' . $data->ds_foto) : asset('img/no-image.png')); ?>"
                                             alt="Avatar" title="Change the avatar" style="width: 100%">
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 text-center mt-2">
                                    <input id="ds_foto" type="file"
                                           class="form-control form-control-sm inputFoto"
                                           name="ds_foto" value="<?php echo e($data->ds_foto); ?>"/>
                                    <label for="ds_foto" class="custom-upload-foto" style="width: 100%;">
                                        <i class="fa fa-cloud-upload"></i> <?php echo e($data->ds_foto == "" ? 'Carregar foto' : $data->ds_foto); ?>

                                    </label>
                                    <p id="file_invalid" class="alert alert-error mt-3" style="display: none;">Formato
                                        de arquivo invalido! <br/>
                                        Aceito apenas imagens nos formatos .png, .jpeg, .jpg
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-10 col-sm-10 ">
                                <input id="id_palestrante" type="hidden" name="id_palestrante" value="<?php echo e($data->id); ?>"/>
                                <input id="id_usuario" type="hidden" name="id_usuario" value="<?php echo e(Auth::user()->id); ?>"/>
                                <div class="col-md-12">
                                    <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="nav-pessoais-tab"
                                               data-toggle="tab"
                                               href="#nav-pessoais" role="tab" aria-controls="nav-pessoais"
                                               aria-selected="true">Dados
                                                Pessoais</a>

                                            <a class="nav-item nav-link" id="nav-contrato-tab" data-toggle="tab"
                                               href="#nav-contrato" role="tab" aria-controls="nav-contrato"
                                               aria-selected="false">Dados
                                                Contratuais</a>

                                            <a class="nav-item nav-link" id="nav-banco-tab" data-toggle="tab"
                                               href="#nav-banco"
                                               role="tab" aria-controls="nav-banco" aria-selected="false">Dados
                                                Bancários</a>

                                            <a class="nav-item nav-link" id="nav-valores-tab" data-toggle="tab"
                                               href="#nav-valores" role="tab" aria-controls="nav-valores"
                                               aria-selected="false">Valores</a>

                                            <a class="nav-item nav-link" id="nav-assessor-tab" data-toggle="tab"
                                               href="#nav-assessor" role="tab" aria-controls="nav-assessor"
                                               aria-selected="false">Assessor</a>

                                            <a class="nav-item nav-link" id="nav-descricao-tab"
                                               data-toggle="tab"
                                               href="#nav-descricao" role="tab" aria-controls="nav-descricao"
                                               aria-selected="false">Descrição</a>

                                            <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab"
                                               href="#nav-video" role="tab" aria-controls="nav-contact"
                                               aria-selected="false">Video</a>
                                        </div>
                                    </nav>
                                    <div class="tab-content p-2" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="nav-pessoais" role="tabpanel"
                                             aria-labelledby="nav-pessoais-tab">
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12">
                                                    <label for="nm_palestrante">Nome do
                                                        Palestrante*</label>
                                                    <input id="nm_palestrante" type="text"
                                                           class="form-control form-control-sm"
                                                           name="nm_palestrante" value="<?php echo e($data->nm_palestrante); ?>"
                                                           autofocus/>
                                                </div>
                                            </div>
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-6">
                                                    <label for="ds_nacionalidade">Nacionalidade*</label>
                                                    <select id="ds_nacionalidade" name="ds_nacionalidade"
                                                            class="form-control form-control-sm">
                                                        <option class="form-control form-control-sm"
                                                                <?php echo e($data->ds_nacionalidade == "" ? 'selected' : ''); ?>

                                                                disabled>
                                                            Selecionar Nacionalidade
                                                        </option>
                                                        <option class="form-control form-control-sm"
                                                                value="Brasileiro" <?php echo e($data->ds_nacionalidade == "Brasileiro" ? 'selected' : ''); ?>>
                                                            Brasileiro
                                                        </option>
                                                        <option class="form-control form-control-sm"
                                                                value="Estrangeiro" <?php echo e($data->ds_nacionalidade == "Estrangeiro" ? 'selected' : ''); ?>>
                                                            Estrangeiro
                                                        </option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="ds_sexo">Sexo*</label>
                                                    <select id="ds_sexo" name="ds_sexo"
                                                            class="form-control form-control-sm">
                                                        <option class="form-control form-control-sm"
                                                                <?php echo e($data->ds_sexo == "" ? 'selected' : ''); ?>

                                                                disabled>
                                                            Selecionar Sexo
                                                        </option>
                                                        <option class="form-control form-control-sm"
                                                                value="Feminino" <?php echo e($data->ds_sexo == "Feminino" ? 'selected' : ''); ?>>
                                                            Feminino
                                                        </option>
                                                        <option class="form-control form-control-sm"
                                                                value="Masculino" <?php echo e($data->ds_sexo == "Masculino" ? 'selected' : ''); ?>>
                                                            Masculino
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-4">
                                                    <label>Disponivel para Palestras</label><br>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio"
                                                               name="ds_ativo"
                                                               id="ds_ativo1"
                                                               value="s" <?php echo e($data->ds_ativo == "s" ? 'checked' : ''); ?>>
                                                        <label class="form-check-label"
                                                               for="ds_ativo1">Sim</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio"
                                                               name="ds_ativo"
                                                               id="ds_disponivel2"
                                                               value="n" <?php echo e($data->ds_ativo == "n" ? 'checked' : ''); ?>>
                                                        <label class="form-check-label"
                                                               for="ds_disponivel2">Não</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <label>Visivel no site</label><br>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio"
                                                               name="ds_visivel_site"
                                                               id="ds_visivel_site"
                                                               value="s" <?php echo e($data->ds_visivel_site == "s" ? 'checked' : ''); ?> />
                                                        <label class="form-check-label"
                                                               for="ds_visivel_site">Sim</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio"
                                                               name="ds_visivel_site"
                                                               id="ds_visivel_site2"
                                                               value="n" <?php echo e($data->ds_visivel_site == "n" ? 'checked' : ''); ?> />
                                                        <label class="form-check-label"
                                                               for="ds_visivel_site2">Não</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label>Ranking do Palestrante</label><br>
                                                    <div class="rate">
                                                        <input type="radio" id="star5" name="rank_palestrante"
                                                               value="5" <?php echo e($data->rank_palestrante == "5" ? 'checked' : ''); ?> />
                                                        <label for="star5" title="text">5
                                                            stars</label>
                                                        <input type="radio" id="star4" name="rank_palestrante"
                                                               value="4" <?php echo e($data->rank_palestrante == "4" ? 'checked' : ''); ?> />
                                                        <label for="star4" title="text">4
                                                            stars</label>
                                                        <input type="radio" id="star3" name="rank_palestrante"
                                                               value="3" <?php echo e($data->rank_palestrante == "3" ? 'checked' : ''); ?> />
                                                        <label for="star3" title="text">3
                                                            stars</label>
                                                        <input type="radio" id="star2" name="rank_palestrante"
                                                               value="2" <?php echo e($data->rank_palestrante == "2" ? 'checked' : ''); ?> />
                                                        <label for="star2" title="text">2
                                                            stars</label>
                                                        <input type="radio" id="star1" name="rank_palestrante"
                                                               value="1" <?php echo e($data->rank_palestrante == "1" ? 'checked' : ''); ?> />
                                                        <label for="star1" title="text">1
                                                            star</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12">
                                                    <?php
                                                        $idiomas = App\Idiomas::all();
                                                    ?>
                                                    <label for="idiomas">Idiomas*</label>
                                                    <select id="idiomas" name="idiomas[]" class="form-control
                                                    form-control-sm select-find" multiple="multiple"
                                                            style="width: 100%">
                                                        <option></option>
                                                        <?php $__currentLoopData = $idiomas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $idiomaPalestrante = App\IdiomasPalestrante::where('id_palestrante', $data->id)
                                                                    ->where('id_idiomas', $item->id)->first();
                                                            ?>
                                                            <?php if(!empty($idiomaPalestrante)): ?>
                                                                <option value="<?php echo e($item->id); ?>"
                                                                        selected="selected">
                                                                    <?php echo e($item->ds_idioma); ?>

                                                                </option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($item->id); ?>">
                                                                    <?php echo e($item->ds_idioma); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12">
                                                    <label for="categorias">Categorias*</label>
                                                    <?php
                                                        $categorias = App\Categoria::all();
                                                    ?>
                                                    <select id="categorias" name="categorias[]"
                                                            class="form-control form-control-sm select-find"
                                                            style="width: 100%" multiple="multiple">
                                                        <option></option>
                                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $categoriaPalestrante = App\PalestranteCategoria::where('id_palestrante', $data->id)
                                                                    ->where('id_categoria', $categoria->id)->first();
                                                            ?>
                                                            <?php if(!empty($categoriaPalestrante)): ?>
                                                                <option value="cat-<?php echo e($categoria->id); ?>"
                                                                        selected="selected">
                                                                    <?php echo e($categoria->nm_categoria); ?>

                                                                </option>
                                                            <?php else: ?>
                                                                <option value="cat-<?php echo e($categoria->id); ?>">
                                                                    <?php echo e($categoria->nm_categoria); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                            <?php $__currentLoopData = $categoria->subCategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $subcategoriaPalestrante = App\PalestranteCategoria::where('id_palestrante', $data->id)
                                                                        ->where('id_subcategoria', $subCategoria->id)->first();
                                                                ?>
                                                                <?php if(!empty($subcategoriaPalestrante)): ?>
                                                                    <option value="sub-<?php echo e($subCategoria->id); ?>"
                                                                            selected="selected">
                                                                        <?php echo e($subCategoria->nm_sub_cat); ?>

                                                                    </option>
                                                                <?php else: ?>
                                                                    <option value="sub-<?php echo e($subCategoria->id); ?>">
                                                                        <?php echo e($subCategoria->nm_sub_cat); ?>

                                                                    </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12 col-sm-12">
                                                    <label for="contatos">Contatos</label>
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmContatoModal">
                                                        <i class="fa fa-plus"></i> Contato
                                                    </button>
                                                </div>
                                                <div class="col-md-10">
                                                    <table id="tblContato" class="table table-sm table-striped">
                                                        <thead>
                                                        <tr>
                                                            <th scope="col">Tipo de Contato</th>
                                                            <th scope="col">Contato</th>
                                                            <th scope="col"></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php if(sizeof($data->contatos) > 0): ?>
                                                            <?php $__currentLoopData = $data->contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr id="<?php echo e($contato->id); ?>">
                                                                    <td><?php echo e($contato->tiposContato->nm_tipo_contato); ?></td>
                                                                    <td><?php echo e($contato->ds_contato); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirBanco-<?php echo e($contato->id); ?>'
                                                                                type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-id=" <?php echo e($contato->id); ?>"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverContatoModal'><i
                                                                                    class='fa fa-trash'></i></button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr id="contato-null">
                                                                <td colspan="3" class="text-center"> Nenhum contato
                                                                    registrado
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12 col-sm-12">
                                                    <label for="contatos">Endereços</label>
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmEnderecoPalestranteModal">
                                                        <i class="fa fa-plus"></i> Endereço
                                                    </button>
                                                </div>
                                                <div class="col-md-10">
                                                    <table id="tblEnderecoPalestrante"
                                                           class="table table-sm table-striped">
                                                        <thead>
                                                        <tr>
                                                            <th scope="col">Tipo de Endereço</th>
                                                            <th scope="col">Endereço</th>
                                                            <th scope="col"></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php if(sizeof($data->enderecos) > 0): ?>
                                                            <?php $__currentLoopData = $data->enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr id="<?php echo e($endereco->id); ?>">
                                                                    <td><?php echo e($endereco->tipoEndereco->nm_tipo_endereco); ?></td>
                                                                    <td><?php echo e($endereco->nm_endereco . " " . $endereco->nr_endereco . ", " . $endereco->nm_bairro . ", " . $endereco->nm_cidade ." - ". $endereco->nm_estado . " - " . $endereco->nr_cep); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirEndereco' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-id="<?php echo e($endereco->id); ?>"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverEnderecoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr id="endereco-null">
                                                                <td colspan="3" class="text-center"> Nenhum endereço
                                                                    registrado
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="nav-contrato" role="tabpanel"
                                             aria-labelledby="nav-profile-tab">
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12">
                                                    <label for="nm_razao_social">Razão Social</label>
                                                    <input id="nm_razao_social" type="text"
                                                           class="form-control form-control-sm"
                                                           name="nm_razao_social"
                                                           value="<?php echo e($data->dadosContratuais->nm_razao_social == "" ? "" : $data->dadosContratuais->nm_razao_social); ?>"
                                                           required/>
                                                </div>
                                            </div>

                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-4">
                                                    <label for="cnpj">CNPJ</label>
                                                    <input id="cnpj" type="text"
                                                           class="form-control form-control-sm"
                                                           data-mask="00.000.000/0000-00" name="nr_cnpj"
                                                           value="<?php echo e($data->dadosContratuais->nr_cnpj == "" ? "" : $data->dadosContratuais->nr_cnpj); ?>"
                                                           required/>
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="insc_estadual">Inscrição Estadual</label>
                                                    <input id="insc_estadual" type="text"
                                                           class="form-control form-control-sm"
                                                           name="nr_insc_estadual"
                                                           value="<?php echo e($data->dadosContratuais->nr_insc_estadual == "" ? "" : $data->dadosContratuais->nr_insc_estadual); ?>"
                                                           required/>
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="insc_municipal">Inscrição Municipal</label>
                                                    <input id="insc_municipal" type="text"
                                                           class="form-control form-control-sm"
                                                           name="nr_insc_municipal"
                                                           value="<?php echo e($data->dadosContratuais->nr_insc_municipal == "" ? "" : $data->dadosContratuais->nr_insc_municipal); ?>"
                                                           required/>
                                                </div>
                                            </div>

                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12">
                                                    <label for="nm_completo">Nome Completo</label>
                                                    <input id="nm_completo" type="text"
                                                           class="form-control form-control-sm"
                                                           name="nm_completo"
                                                           value="<?php echo e($data->dadosContratuais->nm_completo == "" ? "" : $data->dadosContratuais->nm_completo); ?>"
                                                           required/>
                                                </div>
                                            </div>

                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-4">
                                                    <label for="nr_cpf">CPF</label>
                                                    <input id="nr_cpf" type="text"
                                                           class="form-control form-control-sm"
                                                           data-mask="000.000.000-00" name="nr_cpf"
                                                           value="<?php echo e($data->dadosContratuais->nr_cpf == "" ? "" : $data->dadosContratuais->nr_cpf); ?>"
                                                           required/>
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="nr_rg">RG</label>
                                                    <input id="nr_rg" type="text"
                                                           class="form-control form-control-sm"
                                                           name="nr_rg" data-mask="00.000.000-0"
                                                           value="<?php echo e($data->dadosContratuais->nr_rg == "" ? "" : $data->dadosContratuais->nr_rg); ?>"
                                                           required/>
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="dt_nascimento">Data de Nascimento</label>
                                                    <input id="dt_nascimento" type="date"
                                                           class="form-control form-control-sm"
                                                           name="dt_nascimento"
                                                           value="<?php echo e($data->dadosContratuais->dt_nascimento == "" ? "" : $data->dadosContratuais->dt_nascimento); ?>"
                                                           required/>
                                                </div>
                                            </div>

                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-12">
                                                    <label for="ds_observacao">Obsevações</label>
                                                    <textarea id="ds_observacao" type="text"
                                                              class="form-control form-control-sm"
                                                              name="ds_observacao"><?php echo e($data->dadosContratuais->ds_observacao == "" ? "" : $data->dadosContratuais->ds_observacao); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="nav-banco" role="tabpanel"
                                             aria-labelledby="nav-banco-tab">
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-2">
                                                    <div class="form-check form-check-inline">
                                                        <button type="button" class="btn btn-primary btn-sm"
                                                                data-toggle="modal"
                                                                data-target="#frmBancoModal">
                                                            <i class="fa fa-plus"></i> Banco
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="col-md-10">
                                                    <table id="tblBanco" class="table table-sm table-striped">
                                                        <thead>
                                                        <tr>
                                                            <th scope="col">Banco</th>
                                                            <th scope="col">Agencia</th>
                                                            <th scope="col">Conta</th>
                                                            <th scope="col"></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php if(sizeof($data->bancos) > 0): ?>
                                                            <?php $__currentLoopData = $data->bancos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr id="<?php echo e($banco->id); ?>">
                                                                    <td><?php echo e($banco->nomeBanco->nm_banco); ?></td>
                                                                    <td><?php echo e($banco->nr_agencia); ?></td>
                                                                    <td><?php echo e($banco->nr_conta); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirBanco' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-id=" <?php echo e($banco->id); ?>"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverBancoModal'><i
                                                                                    class='fa fa-trash'></i></button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr id="banco-null">
                                                                <td colspan="4" class="text-center"> Nenhum banco
                                                                    registrado
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="nav-valores" role="tabpanel"
                                             aria-labelledby="nav-valores-tab">

                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-2">
                                                    <div class="form-check form-check-inline">
                                                        <button type="button" class="btn btn-primary btn-sm"
                                                                data-toggle="modal"
                                                                data-target="#frmValorModal">
                                                            <i class="fa fa-plus"></i> Valor
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="col-md-10">
                                                    <table id="tblValor" class="table table-sm table-striped">
                                                        <thead>
                                                        <tr>
                                                            <th scope="col">Cidade</th>
                                                            <th scope="col">Valor</th>
                                                            <th scope="col"></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php if(sizeof($data->valores) > 0): ?>
                                                            <?php $__currentLoopData = $data->valores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr id="<?php echo e($valor->id); ?>">
                                                                    <td><?php echo e($valor->cidade->nm_cidade); ?></td>
                                                                    <td><?php echo e($valor->nr_valor); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirValor' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-id="<?php echo e($valor->id); ?>"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverValorModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php else: ?>
                                                            <tr id="valor-null">
                                                                <td colspan="3" class="text-center"> Nenhum valor
                                                                    registrado
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="tab-pane fade" id="nav-assessor" role="tabpanel"
                                             aria-labelledby="nav-assessor-tab">
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-2">
                                                    <div class="form-check form-check-inline">
                                                        <button type="button" class="btn btn-primary btn-sm"
                                                                data-toggle="modal"
                                                                data-target="#frmAssessorModal">
                                                            <i class="fa fa-plus"></i> Assessor
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="col-md-10">
                                                    <table class="table table-sm table-striped"
                                                           id="tblAssessor">
                                                        <thead>
                                                        <tr>
                                                            <th scope="col">Nome do Assessor</th>
                                                            <th scope="col"></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php if(sizeof($data->assessores) > 0): ?>
                                                            <?php $__currentLoopData = $data->assessores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr id="<?php echo e($assessor->id); ?>">
                                                                    <td><?php echo e($assessor->nm_acessor); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirAssessor' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-id="<?php echo e($assessor->id); ?>"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverAssessorModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php else: ?>
                                                            <tr id="assesssor-null">
                                                                <td colspan="2" class="text-center"> Nenhum assessor
                                                                    registrado
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="nav-descricao" role="tabpanel"
                                             aria-labelledby="nav-contact-tab">
                                            <div class="form-group row d-flex justify-content-center text-center">
                                                <div class="col-md-12">
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmChamadaModal">
                                                        Chamada
                                                    </button>
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmCurriculoModal">
                                                        Currículo
                                                    </button>
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmCurriculoTecModal">
                                                        Currículo Técnico
                                                    </button>
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmFormaPagamentoModal">
                                                        Forma de Pagamento
                                                    </button>

                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmInvestimentoModal">
                                                        Investimento
                                                    </button>
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmEquipamentoModal">
                                                        Equipamentos Necessários
                                                    </button>
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#frmObservacaoModal">
                                                        Observações
                                                    </button>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table table-sm table-striped"
                                                           id="tblDescricao">
                                                        <thead>
                                                        <tr>
                                                            <th scope="col">Descrição</th>
                                                            <th scope="col">Conteúdo</th>
                                                            <th scope="col"></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php if($data->ds_chamada != NULL
                                                            || $data->ds_curriculo != NULL
                                                            || $data->ds_curriculo_tecnico != NULL
                                                            || $data->ds_observacao != NULL
                                                            || $data->ds_investimento != NULL
                                                            || $data->ds_forma_pagamento != NULL
                                                            || $data->ds_equipe_necessario != NULL): ?>

                                                            <?php if($data->ds_chamada != NULL): ?>
                                                                <tr id="chamada">
                                                                    <td>Chamada</td>
                                                                    <td class='text-truncate'><?php echo e($data->ds_chamada); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirDescricao' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-tipo="chamada"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverDescricaoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>

                                                            <?php if($data->ds_curriculo != NULL): ?>
                                                                <tr id="curriculo">
                                                                    <td>Currículo Resumido</td>
                                                                    <td class='text-truncate'><?php echo e($data->ds_curriculo); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirDescricao' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-tipo="curriculo"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverDescricaoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>

                                                            <?php if($data->ds_curriculo_tecnico != NULL): ?>
                                                                <tr id="curriculoTec">
                                                                    <td>Currículo Técnico</td>
                                                                    <td class='text-truncate'><?php echo e($data->ds_curriculo_tecnico); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirDescricao' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-tipo="curriculoTec"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverDescricaoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>

                                                            <?php if($data->ds_observacao != NULL): ?>
                                                                <tr id="obs">
                                                                    <td>Observações</td>
                                                                    <td class='text-truncate'><?php echo e($data->ds_observacao); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirDescricao' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-tipo="obs"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverDescricaoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>

                                                            <?php if($data->ds_investimento != NULL): ?>
                                                                <tr id="investimento">
                                                                    <td>Investimento</td>
                                                                    <td class='text-truncate'><?php echo e($data->ds_investimento); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirDescricao' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-tipo="investimento"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverDescricaoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>

                                                            <?php if($data->ds_forma_pagamento != NULL): ?>
                                                                <tr id="pgto">
                                                                    <td>Forma de Pagamento</td>
                                                                    <td class='text-truncate'><?php echo e($data->ds_forma_pagamento); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirDescricao' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-tipo="pgto"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverDescricaoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>

                                                            <?php if($data->ds_equipe_necessario != NULL): ?>
                                                                <tr id="equipamento">
                                                                    <td>Equipamento Necessário</td>
                                                                    <td class='text-truncate'><?php echo e($data->ds_equipe_necessario); ?></td>
                                                                    <td class='text-right'>
                                                                        <button id='excluirDescricao' type='button'
                                                                                class='btn btn-danger btn-sm'
                                                                                data-tipo="equipamento"
                                                                                data-toggle='modal'
                                                                                data-target='#frmRemoverDescricaoModal'>
                                                                            <i class='fa fa-trash'></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>

                                                        <?php else: ?>
                                                            <tr id="descricao-null">
                                                                <td colspan="3" class="text-center"> Nenhuma
                                                                    descrição registrada
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="nav-video" role="tabpanel"
                                             aria-labelledby="nav-contact-tab">
                                            <div class="form-group row d-flex justify-content-center">
                                                <div class="col-md-6">
                                                    <label for="ds_titulo_video">Titulo</label>
                                                    <input id="ds_titulo_video" type="text"
                                                           class="form-control form-control-sm"
                                                           name="ds_titulo_video"
                                                           value="<?php echo e($data->ds_titulo_video == "" ? "" : $data->ds_titulo_video); ?>"/>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="ds_url_video">URL</label>
                                                    <input id="ds_url_video" type="text"
                                                           class="form-control form-control-sm"
                                                           name="ds_url_video"
                                                           value="<?php echo e($data->ds_url_video == "" ? "" : $data->ds_url_video); ?>"/>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="ds_descricao_video">Descrição</label>
                                                    <textarea id="ds_descricao_video" type="text"
                                                              class="form-control form-control-sm"
                                                              name="ds_descricao_video"
                                                              title="Descrição do Video"><?php echo e($data->ds_descricao_video == "" ? "" : $data->ds_descricao_video); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ln_solid"></div>
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-save"></i> Salvar
                                        </button>
                                        <button type="button" class="btn btn-danger btn-sm">
                                            <i class="fa fa-close"></i> Cancelar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('dashboard.banco.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.valor.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.idiomas.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.contato.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.assessor.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.endereco.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.chamada.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.curriculo.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.observacao.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.investimento.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.formaPagamento.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.equipNecessario.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.curriculoTecnico.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('dashboard.banco.remover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.valor.remover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.contato.remover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.assessor.remover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.endereco.remover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.descricao.remover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>