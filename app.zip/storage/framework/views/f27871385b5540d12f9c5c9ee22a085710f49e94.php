<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Palestrante</h3>
            </div>
            <div class="title_right text-right align-content-center">
                <button type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#frmNomePalestranteModal"><i class="fa fa-plus "></i>
                    Palestrante
                </button>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                    <div class="x_content">

                        <?php
                            $palestrantes = App\Palestrante::where('id','>',0)->paginate(10);
                        ?>
                        <div class="row justifi-content">
                            <div class="col-md-12 ">
                                <table class="table table-striped table-sm table-hover">
                                    <thead class="thead-light">
                                    <tr>
                                        <th style="width: 60%">Palestrante</th>
                                        <th>Data da Alteração</th>
                                        <th>Usuário Alteração</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $palestrantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $palestrante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $usuario = App\User::find($palestrante->id_usuario);
                                        ?>
                                        <tr>
                                            <td><?php echo e($palestrante->nm_palestrante); ?></td>
                                            <td><?php echo e(date_format($palestrante->updated_at,"d/m/Y H:i:s")); ?></td>
                                            <td><?php echo e($usuario->name); ?></td>
                                            <td class=" text-right">
                                                <a href="/dashboard/palestrante/<?php echo e($palestrante->id); ?>/edit" class="btn btn-primary btn-sm ml-1"><i
                                                            class='fa fa-edit'></i></a>

                                                <button type="button" class="btn btn-danger btn-sm ml-1"
                                                        data-toggle="modal"
                                                        data-target="#modalPalestranteDel<?php echo e($palestrante->id); ?>"><i
                                                            class='fa fa-trash'></i></button>
                                                <?php echo $__env->make('dashboard.palestrante.delete',['palestrante'=>$palestrante], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end">
                                    <?php echo e($palestrantes->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('dashboard.palestrante.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>